/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.proyecto.tarot.resources;

import com.proyecto.tarot.dao.TarotistasDAO;
import com.proyecto.tarot.model.TarotistasDTO;
import jakarta.ws.rs.GET;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;
import java.sql.SQLException;
import java.util.List;
import org.json.JSONArray;
import org.json.JSONObject;

@Path("/tarotistas")
public class TarotistasResource {
     private final TarotistasDAO dao = new TarotistasDAO();
     @GET
@Produces(MediaType.APPLICATION_JSON)
public Response listarTarotistas() throws SQLException {

    List<TarotistasDTO> tarotistas = (List<TarotistasDTO>) dao.listarTodos(); 

    JSONArray lista = new JSONArray();

    for (TarotistasDTO t : tarotistas) {
        JSONObject obj = new JSONObject();
        obj.put("nombre", t.getNombre());
        obj.put("modalidad", t.getModalidad());
        obj.put("descripcion", t.getDescripcion());
        lista.put(obj);
    }

    JSONObject result = new JSONObject();
    result.put("tarotistas", lista);

    return Response.ok(result.toString()).build();
}
}
