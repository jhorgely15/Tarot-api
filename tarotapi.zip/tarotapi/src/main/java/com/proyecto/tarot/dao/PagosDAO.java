/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

package com.proyecto.tarot.dao;

import com.proyecto.tarot.db.ConexionDB;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class PagosDAO {

    public boolean pagarCita(int idCita, int monto) {

        String sqlPago = "UPDATE pagos SET estado = 'pagado', metodo_pago = 'tarjeta' WHERE id_cita = ?";

        String sqlCita = "UPDATE citas SET estado = 'confirmada' WHERE id_cita = ?";

        try (Connection conn = ConexionDB.getConnection()) {

            conn.setAutoCommit(false);

            try (PreparedStatement stmtPago = conn.prepareStatement(sqlPago)) {
                stmtPago.setInt(1, idCita); 
                stmtPago.executeUpdate(); 
            }

            try (PreparedStatement stmtCita = conn.prepareStatement(sqlCita)) {
                stmtCita.setInt(1, idCita);
                stmtCita.executeUpdate();
            }

            conn.commit(); //guardar los cambios realizados en la bdd
            return true;

        } catch (SQLException e) {
            System.err.println("Error en PagosDAO.pagarCita(): " + e.getMessage());
            return false;
        }
    }
}