/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.proyecto.tarot.resources;

import com.proyecto.tarot.dao.PagosDAO;
import jakarta.ws.rs.Consumes;
import jakarta.ws.rs.POST;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;
import org.json.JSONObject;

@Path("/pagos")
public class PagosResource {

    private final PagosDAO pagosDAO = new PagosDAO();
    @POST
    @Path("/pagar")
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    public Response pagar(String jsonInput) {

        JSONObject input = new JSONObject(jsonInput);

        int idCita = input.getInt("idCita");
        int monto = input.getInt("monto");

        boolean exito = pagosDAO.pagarCita(idCita, monto); // true: pago procesado false: si hub un problema

        JSONObject result = new JSONObject();

        if (exito) {
            result.put("mensaje", "Pago realizado correctamente");
            result.put("idCita", idCita);
            result.put("monto", monto);
            result.put("estado", "pagado");

            return Response.ok(result.toString()).build();
        } else {
            result.put("mensaje", "Error al procesar el pago");

            return Response.status(Response.Status.INTERNAL_SERVER_ERROR)
                           .entity(result.toString())
                           .build();
        }
    }
}
	