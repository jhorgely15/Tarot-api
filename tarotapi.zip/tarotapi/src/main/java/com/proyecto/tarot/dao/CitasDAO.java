/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template

 */

package com.proyecto.tarot.dao;

import com.proyecto.tarot.model.CitasDTO;

import java.sql.*;
import com.proyecto.tarot.db.ConexionDB;
import java.util.HashMap;
import java.util.Map;

public class CitasDAO {

    public CitasDTO registrar(CitasDTO cita) throws SQLException {

        String sql = "INSERT INTO citas (id_usuario, id_tarotista, id_servicio, fecha, hora, modalidad, estado) "
                   + "VALUES (?, ?, ?, ?, ?, ?, ?)";

        try (Connection conn = ConexionDB.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {

            pstmt.setInt(1, cita.getIdUsuario());
            pstmt.setInt(2, cita.getIdTarotista());
            pstmt.setInt(3, cita.getIdServicio());
            pstmt.setDate(4, Date.valueOf(cita.getFecha()));
            pstmt.setTime(5, Time.valueOf(cita.getHora()));
            pstmt.setString(6, cita.getModalidad());
            pstmt.setString(7, cita.getEstado());

            pstmt.executeUpdate();

            try (ResultSet rs = pstmt.getGeneratedKeys()) {
                if (rs.next()) {
                    cita.setIdCita(rs.getInt(1));
                }
            }
        }

        return cita;
    }

    public Map<String, Integer> listarServicios() throws SQLException {

        String sql = "SELECT id_servicio, nombre FROM servicios";
        Map<String, Integer> mapServicios = new HashMap<>();

        try (Connection conn = ConexionDB.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {

            while (rs.next()) {
                int id = rs.getInt("id_servicio");
                String nombre = rs.getString("nombre");
                mapServicios.put(nombre, id);
            }
        }

        return mapServicios;
    }

    public Map<String, Integer> listarTarotistas() throws SQLException {

        String sql = "SELECT id_tarotista, nombre FROM tarotistas";
        Map<String, Integer> mapTarotistas = new HashMap<>();

        try (Connection conn = ConexionDB.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {

            while (rs.next()) {
                int id = rs.getInt("id_tarotista");
                String nombre = rs.getString("nombre");
                mapTarotistas.put(nombre, id);
            }
        }

        return mapTarotistas;
    }
}
