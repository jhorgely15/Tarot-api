/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.proyecto.tarot.resources;

import com.proyecto.tarot.dao.ServiciosDAO;
import com.proyecto.tarot.model.ServiciosDTO;
import jakarta.ws.rs.GET;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;
import java.sql.SQLException;
import java.util.List;
import org.json.JSONArray;
import org.json.JSONObject;

/**
 *
 * @author alumno
 */
@Path ("/servicios")
public class ServiciosResource {
    private final ServiciosDAO dao = new ServiciosDAO();

@GET
@Produces(MediaType.APPLICATION_JSON)
public Response listarServicios() throws SQLException {
     
List<ServiciosDTO> servicios = (List<ServiciosDTO>) dao.listarServicios(); //se obtiene una lista de objetos desde la bdd

    JSONArray lista = new JSONArray();

    for (ServiciosDTO s : servicios) {
        JSONObject obj = new JSONObject();
        obj.put("id_servicio", s.getIdServicio());
        obj.put("nombre", s.getNombre());
        obj.put("descripcion", s.getDescripcion());
        obj.put("precio", s.getPrecio());
        obj.put("duracion_minutos", s.getDuracion());
        lista.put(obj);
    }

    JSONObject result = new JSONObject();
    result.put("servicios", lista);

    return Response.ok(result.toString()).build();
}
}

