/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.proyecto.tarot.resources;

import com.proyecto.tarot.dao.CitasDAO;
import com.proyecto.tarot.db.ConexionDB;
import com.proyecto.tarot.model.ServiciosDTO;
import jakarta.ws.rs.Consumes;
import jakarta.ws.rs.GET;
import jakarta.ws.rs.POST;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import org.json.JSONObject;
import org.json.JSONArray;
import java.util.List;
import java.util.Map;
import org.json.JSONException;

@Path("/citas")
public class CitasResource {

    private final CitasDAO dao = new CitasDAO();

    @POST
    @Path("/registrar")
    @Produces(MediaType.APPLICATION_JSON)
    @Consumes(MediaType.APPLICATION_JSON)
    public Response registrar(String jsonBody) { 

        JSONObject result = new JSONObject();

        try {

            JSONObject input = new JSONObject(jsonBody);

            try (Connection con = ConexionDB.getConnection()) {
                String sql = "INSERT INTO citas (id_usuario, id_tarotista, id_servicio, fecha, hora, modalidad, estado) "
                           + "VALUES (?, ?, ?, ?, ?, ?, ?)";

                PreparedStatement ps = con.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS);

                ps.setInt(1, input.getInt("idUsuario")); 
                ps.setInt(2, input.getInt("idTarotista"));
                ps.setInt(3, input.getInt("idServicio"));
                ps.setString(4, input.getString("fecha"));
                ps.setString(5, input.getString("hora"));
                ps.setString(6, input.getString("modalidad"));
                ps.setString(7, input.getString("estado"));

                int filas = ps.executeUpdate();

                if (filas > 0) {
                    ResultSet rs = ps.getGeneratedKeys();
                    if (rs.next()) {
                        int idCita = rs.getInt(1);
                        result.put("mensaje", "Cita registrada con éxito");
                        result.put("idCita", idCita);
                    }
                    return Response.status(Response.Status.CREATED).entity(result.toString()).build();
                } else {
                    result.put("error", "No se pudo registrar la cita");
                    return Response.status(Response.Status.BAD_REQUEST).entity(result.toString()).build();
                }
            }

        } catch (SQLException | JSONException e) { 
            JSONObject error = new JSONObject();
            error.put("error", "Error al registrar la cita");
            error.put("detalle", e.getMessage());
            return Response.status(500).entity(error.toString()).build();
        }
    }

@GET
@Path("/servicios")
@Produces(MediaType.APPLICATION_JSON)
public Response listarServicios() {
    JSONObject result = new JSONObject();
    
    try {
        Map<String, Integer> mapa = dao.listarServicios(); 
        JSONArray lista = new JSONArray();

        // Recorremos el mapa (Clave=Nombre, Valor=ID)
        mapa.forEach((nombre, id) -> {
            JSONObject obj = new JSONObject();
            obj.put("id_servicio", id);
            obj.put("nombre", nombre);
            lista.put(obj);
            result.put("servicios", lista);
            result.put("mensaje", "Lista obtenida correctamente");
        });
             
            return Response.ok(result.toString()).build();

        } catch (SQLException e) {
            result.put("error", "Error al obtener servicios");
            result.put("detalle", e.getMessage());
            return Response.status(Response.Status.INTERNAL_SERVER_ERROR)
                           .entity(result.toString())
                           .build();
        }
    }

    @GET
    @Path("/tarotistas")
    @Produces(MediaType.APPLICATION_JSON)
    public Response listarTarotistas() {
        JSONObject result = new JSONObject();

        try {
            Map<String, Integer> mapa = dao.listarTarotistas();
            JSONArray lista = new JSONArray();

            // Iteramos el mapa (Clave: Nombre, Valor: ID)
            mapa.forEach((nombre, id) -> {
                JSONObject obj = new JSONObject();
                obj.put("id_tarotista", id);
                obj.put("nombre", nombre);
                lista.put(obj);
            });

            result.put("tarotistas", lista);
            result.put("mensaje", "Lista obtenida correctamente");

            return Response.ok(result.toString()).build();

        } catch (SQLException e) {
            result.put("error", "Error al obtener tarotistas");
            result.put("detalle", e.getMessage());
            return Response.status(Response.Status.INTERNAL_SERVER_ERROR)
                           .entity(result.toString())
                           .build();
        }
    }
}