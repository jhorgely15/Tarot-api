/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

package com.proyecto.tarot.dao;

import com.proyecto.tarot.model.ServiciosDTO;
import com.proyecto.tarot.db.ConexionDB;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class ServiciosDAO {

    public List<ServiciosDTO> listarServicios() {

        List<ServiciosDTO> lista = new ArrayList<>();

        String sql = "SELECT id_servicio, nombre, descripcion, precio, duracion_minutos FROM servicios";

        try (
                Connection conn = ConexionDB.getConnection();
                PreparedStatement stmt = conn.prepareStatement(sql);
                ResultSet rs = stmt.executeQuery()
        ) {

            while (rs.next()) {

                ServiciosDTO dto = new ServiciosDTO(
                        rs.getInt("id_servicio"),
                        rs.getString("nombre"),
                        rs.getString("descripcion"),
                        rs.getDouble("precio"),
                        rs.getInt("duracion_minutos")
                );

                lista.add(dto);
            }

        } catch (SQLException e) {

            System.err.println("Error en ServiciosDAO.listarServicios(): " + e.getMessage());
        }

        return lista;
    }
}