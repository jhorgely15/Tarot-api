/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

package com.proyecto.tarot.model;
import java.time.LocalDate;
import java.time.LocalTime;

public class CitasDTO {

    private int idCita;
    private int idUsuario;
    private int idTarotista;
    private int idServicio;
    private LocalDate fecha;
    private LocalTime hora;
    private String modalidad;
    private String estado;

    public CitasDTO() {}

    public CitasDTO(int idCita, int idUsuario, int idTarotista, int idServicio,
                    LocalDate fecha, LocalTime hora, String modalidad, String estado) {

        this.idCita = idCita;
        this.idUsuario = idUsuario;
        this.idTarotista = idTarotista;
        this.idServicio = idServicio;
        this.fecha = fecha;
        this.hora = hora;
        this.modalidad = modalidad;
        this.estado = estado;
    }

    public int getIdCita() { return idCita; }
    public void setIdCita(int idCita) { this.idCita = idCita; }

    public int getIdUsuario() { return idUsuario; }
    public void setIdUsuario(int idUsuario) { this.idUsuario = idUsuario; }

    public int getIdTarotista() { return idTarotista; }
    public void setIdTarotista(int idTarotista) { this.idTarotista = idTarotista; }

    public int getIdServicio() { return idServicio; }
    public void setIdServicio(int idServicio) { this.idServicio = idServicio; }

    public LocalDate getFecha() { return fecha; }
    public void setFecha(LocalDate fecha) { this.fecha = fecha; }

    public LocalTime getHora() { return hora; }
    public void setHora(LocalTime hora) { this.hora = hora; }

    public String getModalidad() { return modalidad; }
    public void setModalidad(String modalidad) { this.modalidad = modalidad; }

    public String getEstado() { return estado; }
    public void setEstado(String estado) { this.estado = estado; }

    @Override
    public String toString() {
        return "CitasDTO{" +
                "idCita=" + idCita +
                ", idUsuario=" + idUsuario +
                ", idTarotista=" + idTarotista +
                ", idServicio=" + idServicio +
                ", fecha=" + fecha +
                ", hora=" + hora +
                ", modalidad='" + modalidad + '\'' +
                ", estado='" + estado + '\'' +
                '}';
    }
}
