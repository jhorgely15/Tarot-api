/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

package com.proyecto.tarot.dao;

import com.proyecto.tarot.model.TarotistasDTO;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import com.proyecto.tarot.db.ConexionDB;

public class TarotistasDAO {

    public List<TarotistasDTO> listarTodos() throws SQLException {

        String sql = "SELECT nombre, modalidad, descripcion FROM tarotistas";

        List<TarotistasDTO> list = new ArrayList<>();

        try (Connection conn = ConexionDB.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql);
             ResultSet rs = pstmt.executeQuery()) {

            while (rs.next()) {
                TarotistasDTO t = new TarotistasDTO();
                
                t.setNombre(rs.getString("nombre"));
                t.setModalidad(rs.getString("modalidad"));
                t.setDescripcion(rs.getString("descripcion"));

                list.add(t);
            }
        }

        return list; 
    }

}