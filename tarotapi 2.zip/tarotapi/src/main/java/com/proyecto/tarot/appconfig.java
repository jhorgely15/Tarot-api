/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.proyecto.tarot;

import jakarta.ws.rs.ApplicationPath;
import jakarta.ws.rs.core.Application;
import java.util.HashSet;
import java.util.Set;
import com.proyecto.tarot.resources.CitasResource;
import com.proyecto.tarot.resources.PagosResource;
import com.proyecto.tarot.resources.ServiciosResource;
import com.proyecto.tarot.resources.TarotistasResource;
import com.proyecto.tarot.resources.UsuariosResource;

@ApplicationPath("/api")
public class appconfig extends Application {

    @Override
    public Set<Class<?>> getClasses() {
        Set<Class<?>> resources = new HashSet<>();
        resources.add(CitasResource.class);
        resources.add(PagosResource.class);
        resources.add(ServiciosResource.class);
        resources.add(TarotistasResource.class);
        resources.add(UsuariosResource.class);
        return resources;
    }
}
