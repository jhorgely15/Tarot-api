/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

package com.proyecto.tarot.model;

public class ServiciosDTO {

    private final int idServicio;     
    private final String nombre;     
    private final String descripcion; 
    private final double precio;      
    private final int duracion;      

    public ServiciosDTO(int idServicio, String nombre, String descripcion, double precio, int duracion) {
        this.idServicio = idServicio;
        this.nombre = nombre;
        this.descripcion = descripcion;
        this.precio = precio;
        this.duracion = duracion;
    }

    public int getIdServicio() { return idServicio; }

    public String getNombre() { return nombre; }

    public String getDescripcion() { return descripcion; }

    public double getPrecio() { return precio; }

    public int getDuracion() { return duracion; }
}