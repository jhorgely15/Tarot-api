/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

package com.proyecto.tarot.model;

public class TarotDTO {

    private int idCarta;     
    private String nombre;    
    private String significado;
    private String imagen;   
    private int numero;      
    public TarotDTO() {}

    public TarotDTO(int idCarta, String nombre, String significado, String imagen, int numero) {
        this.idCarta = idCarta;
        this.nombre = nombre;
        this.significado = significado;
        this.imagen = imagen;
        this.numero = numero;
    }

    public int getIdCarta() { return idCarta; }
    public void setIdCarta(int idCarta) { this.idCarta = idCarta; }

    public String getNombre() { return nombre; }
    public void setNombre(String nombre) { this.nombre = nombre; }

    public String getSignificado() { return significado; }
    public void setSignificado(String significado) { this.significado = significado; }

    public String getImagen() { return imagen; }
    public void setImagen(String imagen) { this.imagen = imagen; }

    public int getNumero() { return numero; }
    public void setNumero(int numero) { this.numero = numero; }

    @Override
    public String toString() {
        return "TarotDTO{" +
                "idCarta=" + idCarta +
                ", nombre='" + nombre + '\'' +
                ", numero=" + numero +
                ", imagen='" + imagen + '\'' +
                '}';
    }
}