/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

package com.proyecto.tarot.model;

public class UsuariosDTO {

    private int idUsuario;   
    private String nombre;  
    private String email;    
    private String region;   
    private String comuna;  

    public UsuariosDTO() {}

    public UsuariosDTO(int idUsuario, String nombre, String email, String region, String comuna) {
        this.idUsuario = idUsuario;
        this.nombre = nombre;
        this.email = email;
        this.region = region;
        this.comuna = comuna;
    }

    public int getIdUsuario() {
        return idUsuario;
    }

    public void setIdUsuario(int idUsuario) {
        this.idUsuario = idUsuario;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getRegion() {
        return region;
    }

    public void setRegion(String region) {
        this.region = region;
    }

    public String getComuna() {
        return comuna;
    }

    public void setComuna(String comuna) {
        this.comuna = comuna;
    }

    @Override
    public String toString() {
        return "UsuariosDTO{" +
                "idUsuario=" + idUsuario +
                ", nombre='" + nombre + '\'' +
                ", email='" + email + '\'' +
                ", region='" + region + '\'' +
                ", comuna='" + comuna + '\'' +
                '}';
    }
}