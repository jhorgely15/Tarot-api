/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

package com.proyecto.tarot.dao;

import com.proyecto.tarot.model.UsuariosDTO;
import java.sql.*;
import com.proyecto.tarot.db.ConexionDB;

public class UsuariosDAO {

    public UsuariosDTO registrarUsuario(UsuariosDTO usuario) throws SQLException {

        String sql = "INSERT INTO usuarios (nombre, email, region, comuna) VALUES (?, ?, ?, ?)";

        try (Connection conn = ConexionDB.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {

            pstmt.setString(1, usuario.getNombre());
            pstmt.setString(2, usuario.getEmail());
            pstmt.setString(3, usuario.getRegion());
            pstmt.setString(4, usuario.getComuna());

            pstmt.executeUpdate(); 

            try (ResultSet rs = pstmt.getGeneratedKeys()) {
                if (rs.next()) {
                    usuario.setIdUsuario(rs.getInt(1));
                }
            }
        }

        return usuario;
    }

    public UsuariosDTO buscarPorId(int id) throws SQLException {

        String sql = "SELECT id, nombre, email, region, comuna FROM usuarios WHERE id = ?";
        UsuariosDTO u = null;

        try (Connection conn = ConexionDB.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {

            pstmt.setInt(1, id); 

            try (ResultSet rs = pstmt.executeQuery()) {
                if (rs.next()) {
                    u = new UsuariosDTO();
                    u.setIdUsuario(rs.getInt("id"));
                    u.setNombre(rs.getString("nombre"));
                    u.setEmail(rs.getString("email"));
                    u.setRegion(rs.getString("region"));
                    u.setComuna(rs.getString("comuna"));
                }
            }
        }

        return u;
    }
}