/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */


package com.proyecto.tarot.model;


public class PagosDTO {

    private final int idPago;        
    private final int idCita;        
    private final String estado;    
    private final String metodoPago; 
    private final int monto;        

    public PagosDTO(int idPago, int idCita, String estado, String metodoPago, int monto) {
        this.idPago = idPago;
        this.idCita = idCita;
        this.estado = estado;
        this.metodoPago = metodoPago;
        this.monto = monto;
    }

    public int getIdPago() { return idPago; }

    public int getIdCita() { return idCita; }

    public String getEstado() { return estado; }

    public String getMetodoPago() { return metodoPago; }

    public int getMonto() { return monto; }
}