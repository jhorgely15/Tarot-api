/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.proyecto.tarot.resources;

import com.proyecto.tarot.db.ConexionDB;
import jakarta.ws.rs.Consumes;
import jakarta.ws.rs.POST;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import org.json.JSONObject;

@Path("/usuarios")
public class UsuariosResource {

    @POST
    @Path("/registrar")
    @Produces(MediaType.APPLICATION_JSON)
    @Consumes(MediaType.APPLICATION_JSON)
    public Response registrar(String jsonInput) { 

        JSONObject result = new JSONObject();

        try (Connection con = ConexionDB.getConnection()) {
     
            JSONObject input = new JSONObject(jsonInput);

            String sql = "INSERT INTO usuarios (nombre, email, region, comuna) VALUES (?, ?, ?, ?)";

            PreparedStatement ps = con.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS);
            
            ps.setString(1, input.getString("nombre"));
            ps.setString(2, input.getString("email"));
            ps.setString(3, input.getString("region"));
            ps.setString(4, input.getString("comuna"));

            int filas = ps.executeUpdate();

            if (filas > 0) {
                ResultSet rs = ps.getGeneratedKeys();
                if (rs.next()) {
                    int idUsuario = rs.getInt(1); 
                    result.put("mensaje", "Usuario registrado con éxito"); 
                    result.put("idUsuario", idUsuario);
                }
            } else {
                result.put("error", "No se pudo registrar el usuario");
                return Response.status(Response.Status.BAD_REQUEST).entity(result.toString()).build();
            }

            return Response.status(Response.Status.CREATED).entity(result.toString()).build();

        } catch (Exception e) {
            JSONObject error = new JSONObject();
            error.put("error", "Error al registrar usuario");
            error.put("detalle", e.getMessage());
            return Response.status(500).entity(error.toString()).build();
        }
    }
  
    @POST
    @Path("/buscar")
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    public Response buscarUsuarioPorId(String jsonInput) {

        JSONObject result = new JSONObject();
        
        String sql = "SELECT * FROM usuarios WHERE id_usuario = ?"; 

        try (Connection con = ConexionDB.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {
            
            JSONObject input = new JSONObject(jsonInput);
            int id = input.getInt("id");

            ps.setInt(1, id);
            ResultSet rs = ps.executeQuery();

            if (rs.next()) {
                result.put("id_usuario", rs.getInt("id_usuario"));
                result.put("nombre", rs.getString("nombre"));
                result.put("email", rs.getString("email"));
                result.put("region", rs.getString("region"));
                result.put("comuna", rs.getString("comuna"));
            } else {
                result.put("error", "No se encontró un usuario con el ID ingresado");
            }

        } catch (Exception e) {
            result.put("error", "Error al consultar la base de datos: " + e.getMessage());
            return Response.status(500).entity(result.toString()).build();
        }

        return Response.ok(result.toString()).build();
    }
}